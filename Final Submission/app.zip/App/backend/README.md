# Run the project

Set the database connection in the `config/databaseConfig.js` to a MongoDB database (Eg. mongodb://localhost:27017)

Run:
- npm install
- npm start
