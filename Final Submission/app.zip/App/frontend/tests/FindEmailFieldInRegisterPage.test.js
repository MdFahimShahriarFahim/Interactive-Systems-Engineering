const { Builder, By, until } = require('selenium-webdriver');
const assert = require('assert');

describe('User Registration and Login Test', () => {
    let driver;

    beforeAll(async () => {
        driver = await new Builder().forBrowser('chrome').build();
    });

    afterAll(async () => {
        await driver.quit();
    });

    test('should open the registration form and locate the email field', async () => {
        try {
            await driver.get('http://localhost:3000/login');

            // Click the "Register" tab
            const registerTab = await driver.findElement(By.xpath('//button[contains(text(), "Register")]'));
            await registerTab.click();

            // Wait for a moment to ensure the registration form is displayed
            await driver.sleep(3000); // Adjust this delay as necessary

            // Attempt to locate the email field
            const emailInput = await driver.findElement(By.xpath('//label[contains(text(), "Email")]/following-sibling::div//input'));
            assert(emailInput, 'Email input field not found');

            console.log('Email input field located successfully.');

        } catch (error) {
            console.error('Test failed', error);
            throw error;
        }
    }, 30000); // Adjusting Jest timeout for the test
});
